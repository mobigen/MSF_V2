#!/bin/sh

./TestClient.exe 10012 localhost:10002 mobigen

