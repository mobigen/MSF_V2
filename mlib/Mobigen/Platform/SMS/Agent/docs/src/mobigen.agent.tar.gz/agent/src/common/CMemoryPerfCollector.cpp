

#include "CMemoryPerfCollector.h"


CMemoryPerfCollector::CMemoryPerfCollector()
{
}

CMemoryPerfCollector::~CMemoryPerfCollector()
{
}

void CMemoryPerfCollector::collect()
{
	char *msg=NULL;

	m_coreview = m_envvar->getKernelCore()->getCoreView();
	if(	scCoreViewMemStatus(m_coreview, &m_memstat)==SC_ERR ||
		scCoreViewVMStatus(m_coreview, &m_vmstat)==SC_ERR )
		return;
	m_envvar->getKernelCore()->returnCoreView(m_coreview);

	makeMessage();
	msg = m_msgfmt.makeMessage();

	if(m_pollitem->getPollType() == TYPE_PASSIVE){
		m_envvar->getRespQ()->enqueue(msg, NULL);		
	}else{
		if(isShortPerf()==true){
			m_envvar->getShortPerfQ()->enqueue(msg, NULL);		
		}else{
			m_envvar->getLongPerfQ()->enqueue(msg, NULL);		
		}
	}
}

void CMemoryPerfCollector::makeMessage()
{
	int i=0;
	char buf[1024], temp[32], tab=0x09;
	CQueue *instQ = m_pollitem->getInstQ();
	elem *e=NULL;

	m_msgfmt.setItem(m_pollitem->getItem());
	m_msgfmt.setPollTime(m_pollitem->getPollTime());
	m_msgfmt.setType(m_pollitem->getPollType());
	if(m_pollitem->getPollType()==TYPE_PASSIVE)
		m_msgfmt.setCommand((char *)m_pollitem->getCommand().c_str());

	memset(buf, 0x00, sizeof(buf));
	sprintf(buf, 	"TotalPhysicalMemory(KB)%cFreePhysicalMemory(KB)%c"
					"PhysicalMemoryUsage(%%)%cTotalSwapMemory(KB)%c"
					"FreeSwapMemory(KB)%cSwapMemoryUsage(%%)%c"
					"PageScan(Count)%cPageOut(Count)%cSwapOut(Count)\n",
					tab, tab, tab, tab, tab, tab, tab, tab);
	m_msgfmt.setTitle(buf);

	memset(buf, 0x00, sizeof(buf));
	sprintf(buf, "%d%c%d%c%.02f%c%d%c%d%c%.02f%c%d%c%d%c%d\n",
			m_memstat.m_total, tab, m_memstat.m_total-m_memstat.m_used, tab,
			m_memstat.m_usage, tab, m_memstat.s_total, tab,
			m_memstat.s_total - m_memstat.s_used, tab,
			m_memstat.s_usage, tab, m_vmstat.scanrate, tab,
			m_vmstat.pageout, tab, m_vmstat.swapout);
	m_msgfmt.addMessage(strdup(buf));

	return;
}
