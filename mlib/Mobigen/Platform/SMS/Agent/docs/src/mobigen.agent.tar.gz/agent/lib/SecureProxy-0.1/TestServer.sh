#!/bin/sh

./TestServer.exe 3000 localhost:3001 abc
