
/*
 *
 * Copyright (C) 2004 r9i9c9,lbdragon. All rights reserved.
 *
 */

/*
 * @author   r9i9c9,lbdragon
 * @version  $Id: u_missing.c,v 1.1.1.1 2004/11/04 02:25:38 r9i9c9 Exp $
 */
