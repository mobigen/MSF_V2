# coding: utf-8

import sys, time
from M6_Cursor import Cursor
from Socket import Socket

VERSION = "Python-M6-API-1.1"

LISTENER_PORT = 7050


class ConnectionFailException(Exception) : pass

class Connection(object) :

	def __init__(self, addr_info, id, password, Direct=False, Debug=False):
		object.__init__(self)

		self.addr_info = addr_info.strip().split(":")
		self.id = id 
		self.password = password 
		self.isDirect = Direct
		self.isDebug = Debug

		self.cursor_ = None
		self.sock_ = Socket()

		# connect
		self.Connect()

	def Connect(self):
		if self.isDebug:
			debugStartTime = time.time()

		# ip
		ip = self.addr_info[0]

		# port
		if len(self.addr_info) > 1:
			port = self.addr_info[1]
		else:
			port = LISTENER_PORT

		# try to connect
		try:
			#if __debug__: print "Trying %s ..." % ":".join(self.addr_info)
			self.sock_.Connect(ip, port)
			#if __debug__: print "Connected to %s." % ":".join(self.addr_info)
		except Exception, e:
			raise ConnectionFailException, "Unable to connect to server.[%s]" % str(e)

		# read welcome message
		(result, msg) = self.sock_.ReadMessage()
		if not result:
			raise ConnectionFailException, "Unable to readMessage. sock"

		if self.isDebug:
			debugEndTime = time.time()
			print "[DEBUG_TIME] Connect() %f" % (debugEndTime - debugStartTime)

	def Cursor(self) :
		return self.cursor()

	def cursor(self) :
		self.cursor_ = Cursor(self.sock_, Debug=self.isDebug)

		if self.isDirect:
			host = self.sock_.sock.getsockname()[0]
			self.cursor_.SetInfo(self.id, self.password, host, VERSION)
		else:
			self.cursor_.Login(self.id, self.password, VERSION)

		return self.cursor_

	def toPrint(self):
		print "addr_info: ", self.addr_info
		print "id: ", self.id 
		print "passwd: ", self.password 
		print "cursor: ", self.cursor_

	def commit(self) :
		pass

	def close(self) :
		self.commit()
		if self.cursor_:
			self.cursor_.Close()

		try: self.sock_.SendMessage("QUIT\r\n", timeOut=1)
		except: pass
		try: self.sock_.Readline(timeOut=1)
		except: pass
		try: self.sock_.close()
		except: pass


def main():

	# listenr
	conn = Connection("58.181.37.135:5050", "id", "passwd")

	# udm
	#conn = Connection("10.0.0.1:5100", "id", "passwd", Direct=True)

	c = conn.Cursor()
	c.SetRecordSep("|^|")

	sql = "show tables"

	c.Execute(sql)

	for a in c:
		print ",".join(a)

	#conn.toPrint()
	conn.close()

if __name__ == "__main__":
	main()
