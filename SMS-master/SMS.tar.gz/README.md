# SMS
Server Management Service 

###main.conf
[EMAIL] SESSION에는 gmail ID, PASSWD 사용가능 합니다.

###main.log
콘솔창에 실행시 Log에 
```
SMTPAuthenticationError: (535, '5.7.8 Username and Password not accepted. 
Learn more at\n5.7.8  https://support.google.com/mail/answer/14257cf7sm18979964pac.41 - gsmtp')
```
와 같은 에러가 발생하면 
```
https://support.google.com/accounts/answer/6010255
```
로 들어가셔서 안전하지 않은 앱을 사용하도록 변경하시면 됩니다.

자세한 것은 메뉴얼을 보시면 됩니다. 
이상입니다.
